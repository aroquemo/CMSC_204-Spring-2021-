package application;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * STUDENT tests for the methods of PasswordChecker
 * @author 
 *
 */
public class PasswordCheckerSTUDENT_Test {

	
	ArrayList <String> passwords;
	
	@Before
	public void setUp() throws Exception {
		
	
		String [] p1 = {"invali", "validPassword1!", "invalidpassword3", "validP1ssWordss2"};
		
		passwords = new ArrayList<String>();
		
		passwords.addAll(Arrays.asList(p1));
		
	}

	@After
	public void tearDown() throws Exception {
		
		passwords = null;
	
	}

	/**
	 * Test if the password is less than 6 characters long.
	 * This test should throw a LengthException for second case.
	 */
	@Test
	public void testIsValidPasswordTooShort()
	{
		
		try {
			
			assertTrue(PasswordCheckerUtility.isValidPassword("a1A#b1Bc1Cd1D"));
			
			PasswordCheckerUtility.isValidPassword("334455BB#");
			
			assertTrue("Unsuccessful Invalid sequence ", false);
		}
		
		catch (LengthException e) {
			

			
			assertTrue("Successful length sequence ", true);
			
		}
		
		catch (Exception e) {
			
			assertTrue("Unsuccessful Invalid sequence ", false);
			
			
			
		}
		
		
		
	}
	
	/**
	 * Test if the password has at least one uppercase alpha character
	 * This test should throw a NoUpperAlphaException for second case
	 */
	@Test
	public void testIsValidPasswordNoUpperAlpha()
	{
		
	try {
			
			assertTrue(PasswordCheckerUtility.isValidPassword("a1A#b1Bc1Cd1D"));
			
			PasswordCheckerUtility.isValidPassword("334455BB#");
			
			assertTrue("Unsuccessful Upper Alpha exception ", false);
		}
		
		catch (NoUpperAlphaException e) {
			

			
			assertTrue("Successful Upper Alpha exception ", true);
			
		}
		
		catch (Exception e) {
			
			assertTrue("Unsuccessful Upper alpha exception ", false);
			
			
			
		}
		
		
		
	}
	
	/**
	 * Test if the password has at least one lowercase alpha character
	 * This test should throw a NoLowerAlphaException for second case
	 */
	@Test
	public void testIsValidPasswordNoLowerAlpha()
	{
		
	try {
			
			assertTrue(PasswordCheckerUtility.isValidPassword("a1A#b1Bc1Cd1D"));
			
			PasswordCheckerUtility.isValidPassword("334455BB#");
			
			assertTrue("Unsuccessful lower Alpha exception ", false);
		}
		
		catch (NoLowerAlphaException e) {
			

			
			assertTrue("Successful no lower alpha exception ", true);
			
		}
		
		catch (Exception e) {
			
			assertTrue("Unsuccessful lower alpha exception ", false);
			
			
			
		}
		
		
		
		
		
	}
	/**
	 * Test if the password has more than 2 of the same character in sequence
	 * This test should throw a InvalidSequenceException for second case
	 */
	@Test
	public void testIsWeakPassword()
	{
		
	try {
			
			assertTrue(PasswordCheckerUtility.isValidPassword("a1A#b1Bc1Cd1D"));
			
			PasswordCheckerUtility.isValidPassword("334455BB#");
			
			
		}
		
		
		catch (Exception e) {
			
			System.out.println(e.getMessage());
			
			assertTrue("Unsuccessful incorrect exception ", false);
			
			
			
		}
		
		
		
	}
	
	/**
	 * Test if the password has more than 2 of the same character in sequence
	 * This test should throw a InvalidSequenceException for second case
	 */
	@Test
	public void testIsValidPasswordInvalidSequence()
	{
		
		
		try {
			
			assertTrue(PasswordCheckerUtility.isValidPassword("a1A#b1Bc1Cd1D"));
			
			PasswordCheckerUtility.isValidPassword("334455BB#");
			
			assertTrue("Unsuccessful invalid password exception ", false);
			
			
		}
			catch(InvalidSequenceException e) {
				
				assertTrue("Successful Invalid sequence ", true);	
		}
		
		catch (Exception e) {
			
			assertTrue(" Unsuccessful Invalid sequence ", false);
		}
		
	}
	
	/**
	 * Test if the password has at least one digit
	 * One test should throw a NoDigitException
	 */
	@Test
	public void testIsValidPasswordNoDigit()
	{
		
		try {
			
			assertTrue(PasswordCheckerUtility.isValidPassword("a1A#b1Bc1Cd1D"));
			
			PasswordCheckerUtility.isValidPassword("334455BB#");
			
			assertTrue("Unsuccessful no digit exception ", false);
			
		}
		
		catch(NoDigitException e) {
			
			assertTrue("Succesful digit exception", true);
			
		}
		
		catch(Exception e) {
		
		assertTrue("Other exception", false);
	
		
		}
		
	}
	
	/**
	 * Test correct passwords
	 * This test should not throw an exception
	 */
	@Test
	public void testIsValidPasswordSuccessful()
	{
		
		try {
			
			assertEquals(true, PasswordCheckerUtility.isValidPassword("a1A#b1Bc1Cd1D"));
			
		}
		
		catch(Exception e) {
			
			System.out.println(e.getMessage());
			
		}
		
		
		
	}
	
	/**
	 * Test the invalidPasswords method
	 * Check the results of the ArrayList of Strings returned by the validPasswords method
	 */
	@Test
	public void testInvalidPasswords() {
		
		ArrayList<String> output;
		
		output = PasswordCheckerUtility.getInvalidPasswords(passwords);
		
		assertEquals(output.size(), 6);
		
		assertEquals(output.get(0), "invali - The password must have atleast 6 characters" );
		
		assertEquals(output.get(1), "INVALID@2 - the password must contain atleast one lower case" );
		
		assertEquals(output.get(3), "Invalid2 - the password must contain one special character ");
		

	}
	
}