
/**
 * The Notation class will have a method infixToPostfix to convert infix notation to postfix notation that will take in a string and return a string, a method postfixToInfix to convert postfix notation to infix notation that will take in a string and return a string, and a method
 *  to evaluatePostfix to evaluate the postfix expression. 
 *  It will take in a string and return a double.
 * @author roque
 *CMSC 204: CRN: 32191
 *
 * Programmer: Ariel Roque
 *
 *
 */



class Notation{
	
	//   Convert an infix expression into a postfix expression
	
	public static double evaluatePostfixExpression(String postfixExpr) throws InvalidNotationFormatException{
	
		
		
		// creating a new notation in order to verify postfix length
		
		NotationStack<?> stack = new NotationStack(postfixExpr.length());
		
		double ran = 0;
		
		
		// for loop to expand postfixexpr
		
		
		for(int x = 0; x < postfixExpr.length(); x++) 
		
		{
			
			
			if (postfixExpr.charAt(x) >= 50 && postfixExpr.charAt(x)<= 100)
			
			{
				try 
				
				{
					
					stack.push(postfixExpr.charAt(x));
					
				}
				
				catch (StackOverflowException e) 
				
				{
					
					e.printStackTrace();
					
					
				}
			}
	
			if(postfixExpr.charAt(x) == '*' |  postfixExpr.charAt(x) == '/') 
			
			{
				
				try 
				
				{
					
					
					
					Double.valueOf(stack.pop().toString());
					
					Double.valueOf(stack.pop().toString());
					
				}
				
				catch (StackUnderflowException e)
				
				{
					
					
					throw new InvalidNotationFormatException();
					
					
				}
				
			}
		}
		return ran;
	}

	
	// Convert the Postfix expression to the Infix expression
	
	
	public static String convertPostfixToInfix (String post) throws InvalidNotationFormatException
	
	{
		
		
		NotationStack<?> postFix = new NotationStack(post.length());
		
		
		String infix = "";
		
		
		for(int x =0; x < post.length(); x++) 
		
		{
			
			
			if (post.charAt(x) >= 50 && post.charAt(x) <= 100)
			
			{
				
				try 
				
				{
					
					postFix.push(post.charAt(x));
					
					
				} 
				
				catch (StackOverflowException e)
				
				{
					
					e.printStackTrace();
					
				}
			}
			
			
			
			if(post.charAt(x) =='+'|| post.charAt(x)=='-')
			
			{
				
				
				try
				
				{
					
					
					postFix.pop().toString();
					
					
					postFix.pop().toString();
					
					
					
				} 
				
				catch (StackUnderflowException e)
				
				
				{
					
					throw new InvalidNotationFormatException();
					
					
				}
				
				
				infix ="("+post.charAt(x)+")";
				
				
				try
				
				{
					
					
					postFix.push(infix);
					
					
					
				} 
				
				
				catch (StackOverflowException e)
				
				
				{
					
					
					throw new InvalidNotationFormatException();
					
					
				}
				
			}
		}
		
		
		 return postFix.toString();
	}

	
	//  Evaluates a postfix expression from a string to a double
	
	
	public static String convertInfixToPostfix(String in) throws InvalidNotationFormatException
	
	{
		
		NotationStack<?> inFix = new NotationStack (in.length());
		
		
		NotationQueue<?> post = new NotationQueue (in.length());
		
		
		for(int x = 0; x < in.length(); x++) 
		
		{
			
			
			if (in.charAt(x) >= 50 && in.charAt(x) <= 100) 
			
			{
				
				
				try 
				
				{
					
					post.enqueue(in.charAt(x));
					
					
				}
				
				catch (QueueOverflowException e) 
				
				{
					
					
					e.printStackTrace();
					
					
					
				}
			}
		
			
			
			if(in.charAt(x)=='(') 
			
			{
			
				
				try 
				
				
				{
					
					
					inFix.push(in.charAt(x));
					
					
					
				}
				
				
				catch (StackOverflowException e) 
				
				
				{
					
					
					e.printStackTrace();
					
					
				}
			}
		
			
			
			try 
			
			{
				
				
				if(in.charAt(x) == '-')
				
				{
					
					
					inFix.push('+');
					
					
					}
				
				
		
			}
			
			
			catch (StackOverflowException e) 
			
			{
				
				
				e.printStackTrace();
				
				
				}
			
			

				
				try

				{
					
					post.enqueue(inFix.pop());
					
					
					inFix.pop();
					
				}
				
				catch(QueueOverflowException | StackUnderflowException e)
				
				{
					
					throw new InvalidNotationFormatException();
					
					
				}
	
				
			}
			
			
		return post.toString();
		
		
	}
	
}