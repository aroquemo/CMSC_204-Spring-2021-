/**
 * NotationQueue will implement the QueueInterface given you. 
 * You will be creating NotationQueue from scratch 
 * (do not use an internal object derived from the Queue interface from the Java API, from java.util)
 * 
 * 
 * *CMSC 204: CRN: 32191
 *
 * Programmer: Ariel Roque
 * 
 */




import java.util.ArrayList;


	public class NotationQueue <T> implements QueueInterface{
		
		private ArrayList <T> q;
		
		
		private int one;
		
	
		public NotationQueue() 
		
		
		{
			
			this.one = 100;
			
			this.q = new ArrayList <> (one);
			
			
		}
	
		
		
		public NotationQueue(int queue) 
		
		{
			
			this.one = queue;
			
			
			this.q = new ArrayList<>(queue);
			
			
		}

		
		
		public NotationQueue(ArrayList<T> newArr)
		
		{
			
			
			this.one = newArr.size();
			
			
			this.q = new ArrayList<>(one);
			
			
			
		}
	
		
	
	
	

		
		
		
		public boolean enqueue(Object e) throws QueueOverflowException
		
		{	
			
			if (isFull() == true)
				
				
				throw new QueueOverflowException();
			
		
				return true;
				
				
			}
		
		
		
// method for toString
		
		public String toString()
		
		{
			
				String message = "";
				
				
				for (int x = 0 ; x < q.size(); x++) 
				
				{
					
					
					message += q.get(x);
					
					
				}
				
				return message;
				
				
		}
		
	
		// for delimiter 
		
		public String toString(String delimiter) 
		
		{
			
			String message = "";
			
			for (int x = 0; x < q.size(); x++) 
			
			{
				
					message += q.get((x)-1);
				
			}
			
			
			return message;
	}
		
		
	public boolean isFull() 
		
		{
			
			if( size() == one)
				
				return true;
			
			
			else return false;
			
			
		}

		
		
public T dequeue() throws QueueUnderflowException
		
		{
			
			if( isEmpty() == true)
			
			{
				
				throw new QueueUnderflowException();
				
			}
			
			else
				
			{
				
				T temp = q.get(0);
			
				
				return temp;
				
				
			}
		}
		
		
		@SuppressWarnings("unchecked")
		
		
		@Override
		
		
		public void fill(ArrayList list) 
		
		{
			
			for(Object b: list) 
			{
				
				q.add ((T) b);
				
				
			}
		}
		
	public int size()
		
		{
			
			return q.size();
			
		}
		
	public boolean isEmpty()
	
	{
		
		
		if( q.isEmpty() != true)
			
			
			return false;
		
		
		else return true;
		
		
	}

	
	
	}
