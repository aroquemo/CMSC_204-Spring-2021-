/**NotationStack will implement the Stack Interface given you. You will be creating NotationStack from scratch 
 * (do not use an internal object of the Stack class from the Java API, java.util)
 *CMSC 204: CRN: 32191
 *
 * *CMSC 204: CRN: 32191
 *
 * Programmer: Ariel Roque
 
 * 
 * 
 */



import java.util.ArrayList;
import java.util.Collection;

public class NotationStack <T> implements StackInterface{
	
	
	// variables
	
	private int priv;
	
	
	private T[] answer;
	
	
	private int main;

	@SuppressWarnings("unchecked")

	
	public NotationStack()
	
	{	
		
		priv = 100;
		
		
		answer = (T[]) new Object[priv];
		
		
		
		main = -1;
		
		
	}

	
	
	
	@SuppressWarnings("unchecked")
	public NotationStack(int stack)
	
	{	
		
		
		this.priv = stack;
		
		
		T[] temp = (T[]) new Object[stack];
		
		
		answer = temp;
		
		
		main =-1;
		
		
		
	}


	
	
	public NotationStack(ArrayList<T> element)
	
	{
		
		this.priv= element.size();
		
		
		
		T[] temp = (T[]) new Object[priv];
		
		
		
		for(int x = 0; x <element.size(); x++) 
		
		
		{
			
			
			temp[x]=element.get(x);
			
			
			
		}
		
		
		answer = temp;
		
		
		
		main = priv-1;
	}




	
	
	
	public T top() throws StackUnderflowException 
	
	{
		
		
		if( isEmpty() == false)
		
		
		{
			
			
			return answer[main];
			
			
			
		}
		
		
		else 
			
			
			
			throw new StackUnderflowException("");
	}



	
	
	
	
	
	public boolean push(Object e) throws StackOverflowException 
	
	{
	
		if( isFull () == false) 
		
		{
			

			
			main ++;
			
			
			return true;
			
			
		}
		else
			
			
			throw new StackOverflowException();

		}
	
	

	
	public boolean isEmpty() 
	
	{
		
		
		if (main < 0) 
		
		{
			
			
			return true;
			
			
			
		}
		
		
		else
			
			
			
		return false;
	}


	
	
	public String toString(String delimiter)
	
	{
		
		
		String message = "";
		
		
		
		for (int x =0; x < size(); x++)
		
		
		{
			
			
			message += answer [x];
			
			
		}
		
		
		
		return message;
	}
	
	
	
	
	public int size()
	
	
	{
		
		return (main);
	
	
	}
	
	
public boolean isFull() 
	
	{
		
		
		if(size()== priv) 
		
		{
			
			
			return true;
			
			
		}
		
		
		
		else 
		
		{
			
			return false;
		}
	}


	
	
	
	
	public T pop() throws StackUnderflowException
	
	
	{
		
		
		if(isEmpty() == false)
		
		
		{
			
			
			T temp = answer [main];
			
			
			answer [main] = null;
			
			
			
			main --;
			
			
			
			return temp;
		}
		
		
		
		else throw new StackUnderflowException("");
		
	}

public String toString() 
	
	{
		
		
		String message = "";
		
		
		for (int x = 0; x < size(); x++)
		
		{
			
			message += answer [x];
			
		}
		
		
		return message;
	}




	@Override
	public void fill(ArrayList list) {
		// TODO Auto-generated method stub
		
	}
}
