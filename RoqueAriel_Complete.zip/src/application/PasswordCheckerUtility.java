package application;


/**
 * CMSC 204 Assignment 1: This assignment is a password checker. The user will be able to create a password and be told the password is valid if it meets all the requirments
 * Have at least one upper and lower case letter, one digit, longer than 6 characters, and 1 special character
 * Based off what the user inputs they will be told what they are missing or whether their password is weak or not.
 * 
 * Professor: Khandan Monshi
 * Class: CMSC 204 CRN: 32191
 * Assignment 1
 * Ariel Roque
 * Due date: 02/08/2021
 */


import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class PasswordCheckerUtility {
	
	
	
	
	public PasswordCheckerUtility(){}
	
	// Check for password comparisons
	
	
	public static void comparePasswords(String password, String checkPassword) throws UnmatchedException{
		
		
		// Checks password and check password strings in order to verify if true
		// if true, throw new exception action will be down
		
		if (comparePasswordsWithReturn(password, checkPassword)==false)
			
			
			throw new UnmatchedException();
		
		
		
		
	}
	
	
	// comparing passwords

	public static boolean comparePasswordsWithReturn(String password, String compare) {
		
		// Using hit given from assignment 1 doc to check for regular expressions and checking the whole passwords
		
		String pass = password;
		
		
		
		Pattern p = Pattern.compile(pass);
		
		
		
		
		Matcher matcher = p.matcher(compare);
		
		
		
		
		return(matcher.matches());
		
	}
	
	
public static ArrayList<String> getInvalidPasswords (ArrayList<String>passwords){
		
		ArrayList <String> invalid = new ArrayList<String>();
		
		
		// For loop in order to implement x into try and catch statements	
			for(int x = 0; x < passwords.size(); x++)
			
			{
				
				//try statement to check for valid passwords of x from for loop
				
				try 
				
				{	
		
					PasswordCheckerUtility.isValidPassword(passwords.get(x));
				
				} 
				
				// catch statement in order to retrieve a message and get the correct message

				catch (Exception e) 
				
				{

					invalid.add(passwords.get(x) + e.getMessage());

				}

			}
			
			// return the valid passwords
			
			return invalid;

}

public static boolean hasBetweenSixAndNineChars(String letters){
	
	
	if(letters.length()>=6)
		
		
		return true;
	
	
	
	else return false;
}


public static boolean hasDigit(String digit) throws NoDigitException{
	
	// Using hit given from assignment 1 doc to check for regular expressions and checking the whole passwords
	
	String pattern = "\\d*";
	
	
	
	
	
	Pattern has = Pattern.compile(pattern);
	
	
	
	
	Matcher matcher = has.matcher(digit);
	
	

	
	if(matcher.matches()== true)
		
		
		
		return true;
	
	
	
	
	else
		
		throw new NoDigitException(" The password must contain at least one digit");
}


public static boolean hasLowerAlpha(String lower) throws NoLowerAlphaException{
	
	
	// Using hit given from assignment 1 doc to check for regular expressions and checking the whole passwords
	
	String p = "*[a-z]*";
	
	Pattern pattern = Pattern.compile(p);
	
	
	
	
	Matcher matcher = pattern.matcher(lower);
	
	
	
	
	
	boolean lowerAlpha = matcher.matches();
	
	
	
	
	if(lowerAlpha == false)
		
		
	
		throw new NoLowerAlphaException(" The password must contain at least one lower case alphabetic character");
	
	
	
	
	return lowerAlpha;	
}




public static boolean hasSameCharInSequence(String ch) throws InvalidSequenceException{
	
	boolean sequence = true;
	
	int zero = 0;
	
	// do while statement to check if characters are used back to back
	
int chara = ch.length()-2;
	
	do{
		
			if (ch.charAt(zero) == ch.charAt(zero + 1)) 
				
				if (ch.charAt(zero) == ch.charAt(zero + 1))

					sequence = false;
			
			zero++;

		
	}
	
	while(zero < chara && sequence !=false);
	
	// if statement to check if sequence is false
	
	if( sequence == false)
		
	
		
		// if sequence is false invalid sequence exception will be called
		
		
		throw new InvalidSequenceException("The password cannot contain more than two of the same character in sequence");
	
	return sequence;
}



public static boolean hasSpecialChar(String special) throws NoSpecialCharacterException{
	
	// Using hit given from assignment 1 doc to check for regular expressions and checking the whole passwords
	
	String ch = "*\\n*";
	
	Pattern pattern = Pattern.compile(ch);
	
	
	
	Matcher matcher = pattern.matcher(special);
	
	
	
	
	boolean specialChar = matcher.matches();
	
	
	
	// if statement to check if sequence is false
	
	if(specialChar == false)
		
		
		// throwing for new no special excpetion
		
		throw new NoSpecialCharacterException(" The password must contain at least one special character");
	
	
	
	
	
	
	return specialChar;
}

public static boolean hasUpperAlpha(String alpha) throws NoUpperAlphaException{
	
	// Using hit given from assignment 1 doc to check for regular expressions and checking the whole passwords
	
	
	String ran = "*[A-Z]*";
	
	
	
	
	
	Pattern upper = Pattern.compile(ran);
	
	
	
	
	
	Matcher matcher = upper.matcher(alpha);
	
	
	
	
	
	boolean upperAlpha = matcher.matches();
	
	
	
	
	
	
	
	if(upperAlpha == false)
	
		
		// throwing new upperalpha exception
		
		throw new NoUpperAlphaException(" The password must contain at least one uppercase alphabetic character");
	
	
	
	
	
	
	
	// return upper alpha
	
	return upperAlpha;	
}



public static boolean isWeakPassword(String weak) throws WeakPasswordException{


	// return  weak if less than or equal to 6 characters or greater than or equal 9 characters
	
	return (weak.length() >= 6 && weak.length() <= 9);
	
	

}

	

	public static boolean isValidLength(String length) throws LengthException{
		
		// if statement to check lenght of password
		
		if (length.length()>= 6)
			
			
			// return if true
			
			return true;
		
		else{
			
			
			// otherwise throw new for length exception
			
			throw new LengthException(" The password must be at least 6 characters long");
		}
		
	}
	


	



	




	public static boolean isValidPassword(String valid) throws LengthException, NoUpperAlphaException,
	NoLowerAlphaException, NoDigitException, NoSpecialCharacterException, InvalidSequenceException{
	 
		
		
		boolean	invalidPassword = true;
		
		boolean	noUpperCaseUsed = false;
		
		boolean noLowerCaseUsed = false;
		
		boolean noDigitsUsed = false;
			
		
	// for loop to help check for validation of password
	
		for (int x = 0; x < valid.length(); x++) {
			
			// using char to help check validation of password
			
			char check = valid.charAt(x);
			
			if (x > 1 && valid.charAt(x - 1) == check && valid.charAt(x - 2) == check )
			
			{
				
				invalidPassword = true;
				
			}
			if (Character.isDigit(x)) 
			
			{
				
			
				noDigitsUsed = true;
				
				
			}
			if (Character.isUpperCase(x))
			
			{
				
				
				
				noUpperCaseUsed = true;
				
				
				
				
			}
			if (Character.isLowerCase(x)) 
			
			
			
			{
				
				
				
				noLowerCaseUsed = true;
			
			
			
			}
		}
		
		
		
	
		
		
		// if statements to help check the validity of each password
		// If password does not meet the requirements, the code will call for the proper exception
		// as well as a display a message to help user figure out what the are missing for
		// a valid password
		
			if (valid.length() < 6 ) 
			{
				
				invalidPassword = false;
				
				throw new LengthException(valid + " Password must have atleast 6 characters.");
				
			}
			
		
			if (noUpperCaseUsed == false)
			{
				
				invalidPassword = false;
				
				throw new NoUpperAlphaException(valid + " Password must have an upper case letter." );
				
			}
			
			
			if (noLowerCaseUsed == false)
			{
				
				invalidPassword = false;
				
				throw new NoLowerAlphaException(valid+ " Password must have an lower case letter.");
				
			}
			
			if (noDigitsUsed == false) 
			
			{
				
				invalidPassword = false;
				
				throw new NoDigitException(valid+ " Password must have one digit letter.");
			}
		
		return invalidPassword;
	}
	

	
	

	
}

