/**A generic sorted double linked list will be constructed using a provided Comparator to determine how the list is to be sorted.  
 * It extends BasicDoubleLinkedList class.  
 * The addToFront and the addToEnd methods will not be supported 
 * and an add method will be added that inserts to the double linked 
 * list in sorted order dependent on the Comparator. 
 * Follow the Javadoc that is provided.
 * Programmer: Ariel Roque
 *  Professor Monshi
 *  CMSC 204, CRN: 32191
 * 
 * 
 */




import java.util.Comparator;
import java.util.ListIterator;

import javax.swing.text.AttributeSet;
import javax.swing.text.html.HTML.Tag;
import javax.swing.text.html.HTMLDocument.Iterator;


public class SortedDoubleLinkedList <T> extends BasicDoubleLinkedList<T>

{
	
	Comparator<T>comparator;

	public SortedDoubleLinkedList(Comparator<T> comparator2)
	
	{
		
		this.comparator=comparator2;
		
	}
	
	public SortedDoubleLinkedList<T> add(T data)
	
	{
		
		return null;
		
	    }

	public BasicDoubleLinkedList<T> addToEnd(T data)
	
	{
		
		throw new UnsupportedOperationException("Invalid operation for sorted list");
		
	}

	public BasicDoubleLinkedList<T> addToFront(T data)
	
	{
		
		throw new UnsupportedOperationException("Invalid operation for sorted list.");
		
	}

	public SortedDoubleLinkedList<T> remove (T data, Comparator<T> comparator)
	
	{
		
		super.remove(data, comparator);
		
		
		return this;
	}
	
}