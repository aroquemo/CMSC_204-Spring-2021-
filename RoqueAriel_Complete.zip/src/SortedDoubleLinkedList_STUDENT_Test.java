import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;




public class SortedDoubleLinkedList_STUDENT_Test {
	SortedDoubleLinkedList<String> sortedLinkedString;
	StringComparator c;
	ListIterator it;


	@Before
	public void setUp() throws Exception {
		c = new StringComparator();
		sortedLinkedString = new SortedDoubleLinkedList<String>(c);
	}

	@After
	public void tearDown() throws Exception {
		sortedLinkedString = null;
	}

	
	@Test
	public void testSort() {
		
		
		assertEquals("[A, C]", sortedLinkedString.toArrayList().toString()); 
		
		assertEquals("[A, B, C]", sortedLinkedString.toArrayList().toString());
		
		assertEquals("[A, B, BB, C]", sortedLinkedString.toArrayList().toString());
		
		assertEquals("[1, A, B, BB, C]", sortedLinkedString.toArrayList().toString());
	
		assertEquals("[1, A, B, BB, C, D]", sortedLinkedString.toArrayList().toString());
		
	}

	
	
	
	private class StringComparator implements Comparator<String>
	{
		public int compare(String arg0, String arg1) {
			return arg0.compareTo(arg1);
		}
	}

	
}