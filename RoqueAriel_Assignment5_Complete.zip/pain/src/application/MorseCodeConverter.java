package application;

/**This class has two static methods convertToEnglish to convert from morse code to English. 
 * One method is passed a string object (�.-.. --- ...- . / .-.. --- --- -.- ...�).  
 * The other method is passed a file to be converted.  
 * These static methods use the MorseCodeTree to convert from morse code to English characters. 
 *  Each method returns a string object of English characters.
 *  Programmer: Ariel Roque
 *  CMSC 204, CRN: 32191
 *  Professor Monshi
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MorseCodeConverter {
	
	private static MorseCodeTree morseTree = new MorseCodeTree();
	
	public static String printTree() 
	
	{
		String printTree= "";
	
		for(int x = 0; x <morseTree.toArrayList().size(); x++) 
		{
			
			if(x == morseTree.toArrayList().size()-1) 
			{
				
				printTree+= morseTree.toArrayList().get(x);
				
			}
			
		}
		
		return printTree;
	}
	
	public static String convertToEnglish(String convert) {
		
		String translation="";
		
		String tempCode="";

		if(convert.charAt(convert.length()-1)!=' ') 
		
		{
			
			convert+=" ";
			
		}
		
		for(int x = 0; x < convert.length(); x++) 
		
		{
			
			if(convert.charAt(x)!=' '&& convert.charAt(x)!='/') 
			
			{
				
				tempCode += convert.charAt(x);
				
			}
			
			if(convert.charAt(x) == ' ')
			
			{
				
				translation += morseTree.fetch(tempCode);
				
				tempCode = "";
				
			}
			
		
			
		}
		
		return translation;
	}
	
	
	public static String convertToEnglish(File codeFile) throws FileNotFoundException
	{
		
		String morseCode= "";
		
		Scanner one = new Scanner(codeFile);
		
		
		while(one.hasNextLine())
			
		{
			
			morseCode += one.nextLine();
			
		}
		
		
		return convertToEnglish(morseCode);
	}
}
