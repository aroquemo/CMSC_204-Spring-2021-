package application;

import java.util.ArrayList;

/**A generic linked binary tree which inherits from the LinkedConverterTreeInterface.  
 * The class uses an external generic TreeNode class parameterized as a String: TreeNode<String>.  
 * This class uses the private member of root.  Nodes are added based on their morse code value.  A �.� (dot) means to traverse left and a �-� (dash) means to traverse right. The constructor will call the method to �build the tree�.  Follow the Javadoc that is provided. The Javadoc only lists those public methods that are required to pass the Junit tests.  
 * You may add any private methods you need for your design.
 * @author roque
 * CMSC 204, CRN: 32191
 * Programmer: Ariel Roque
 * 
 * 
 */



public class MorseCodeTree implements LinkedConverterTreeInterface<String>{
	
	
	@Override
	public String fetchNode(TreeNode <String> root, String code) 
	
	{	
		char[] con = code.toCharArray();
		
		String recent = "";
		
		if(code.length() == 1)
		
		{
			
			if(code.charAt(0)=='.') 
			
			{
				
				return root.getLeft().convert;
				
			}
			
			if(code.charAt(0)=='-')
			
			{
				
				return root.getRight().convert;
				
			}
			
		}
		
		if(code.length()>1)
		
		{
			
			for(int x = 1; x < code.length(); x++) 
			
			{
				
				recent += con[x];
				
			}
			
			if(code.charAt(0)=='.') 
			
			{
				
				return fetchNode(root.getLeft(), recent);
				
			}
			
	
		}
		
		return recent;
	}
	

	
	
	@Override
	public void addNode(TreeNode<String> root, String code, String codeTwo)
	
	{
		if(code.length()==1)
		
		{
			
			if(code.charAt(0)=='.')
			
			{
				
				root.leftTranslation = new TreeNode <> (codeTwo);
				
				nodeAddedSuccessfully(true);
				
			}else nodeAddedSuccessfully(false);
			
		
		}
		
		char[] con = code.toCharArray();
		
		String newCode="";
		
		for(int x = 1; x < code.length(); x++) 
		
		{
			
			newCode += con[x];
			
		}
		if(code.length()>1)
		
		{
			if(code.charAt(0)=='.') 
			
			{
				
				addNode(root.leftTranslation, newCode, codeTwo);
				
				nodeAddedSuccessfully(true);
				
			} else nodeAddedSuccessfully(false);
			
		}
	}
	
	
	public boolean nodeAddedSuccessfully(boolean status) 
	
	{
		
		return status;
		
	}
	
	
	@Override
	public String fetch(String convert)
	
	{
		return fetchNode (root, convert);
	}
	
	
		
	private TreeNode<String> root;
	
	public MorseCodeTree() 
	
	{
		
		buildTree();
		
	}
	
	
	@Override
	public TreeNode<String> getRoot()
	
	{
		
		return this.root;
		
	}
	
	
	
	@Override
	public void setRoot(TreeNode<String> node)
	
	{
		
		this.root = node;
		
	}

	
	
	@Override
	public  MorseCodeTree insert(String code, String convert) 
	
	{
		
		addNode(root, code, convert);
		
		return this;
	}
	
	@Override
	public ArrayList<String> toArrayList() 
	
	{
		ArrayList<String> treeList = new ArrayList<>();
		
        LNRoutputTraversal(root, treeList);
        
        return treeList;
	}
	
	
	
	@Override
	public void LNRoutputTraversal( TreeNode <String> root, ArrayList<String> list)
	
	{
	    if(root == null)
	    	
	    	return;
	    
		LNRoutputTraversal(root.leftTranslation, list);
		
		list.add(root.getData());
		
		LNRoutputTraversal(root.rightTranslation, list);
		
	}
	
	@Override
	public  MorseCodeTree delete(String data) throws UnsupportedOperationException
	
	{
		
		throw new UnsupportedOperationException();
		
	}

	@Override
	public  MorseCodeTree update() throws UnsupportedOperationException 
	
	{
		
		throw new UnsupportedOperationException();
		
	}

	
	
	
	@Override
	public void buildTree() {
		root = new TreeNode<> ("");	
		
        insert(".",    "e");
        
        insert("-",    "t");
        
        insert("..",   "i");
        
        insert(".-",   "a");
        
        insert("-.",   "n");
        
        insert("--",   "m");
        
        insert("...",  "s");
        
        insert("..-",  "u");
        
        insert(".-.",  "r");
        
        insert(".--",  "w");
        
        insert("-..",  "d");
        
        insert("-.-",  "k");
        
        insert("--.",  "g");
        
        insert("---",  "o"); 
        
        insert("....", "h");
        
        insert("...-", "v");
        
        insert("..-.", "f");
        
        insert(".-..", "l");
        
        insert(".--.", "p");
        
        insert(".---", "j");
        
        insert("-...", "b");
        
        insert("-..-", "x");
        
        insert("-.-.", "c");
        
        insert("-.--", "y");
        
        insert("--..", "z");
        
        insert("--.-", "q");
	}
	
	
	
}