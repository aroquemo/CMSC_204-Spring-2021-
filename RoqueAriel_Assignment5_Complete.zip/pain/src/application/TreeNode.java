package application;

/**This generic class is used in the MorseCodeTree classes.  
 * The class consists of a reference to the data and a reference to the left and right child.  
 * Follow the Javadoc that is provided.  
 * The Javadoc only lists those public methods that are required to pass the Junit tests. 
 *  You may add any private methods you need for your design.
 * @author roque
 *Programmer: Ariel Roque
 *CMSC 204, Crn 32191
 * @param <T>
 */

public class TreeNode <T> {
	
	protected TreeNode<T> leftTranslation;
	
	protected TreeNode<T> rightTranslation;
	
	protected T convert;
	
	
	public TreeNode(T dataNode) 
	{
		this.convert = dataNode;
		
		this.leftTranslation = null;
		
		this.rightTranslation = null;
		
	}
	

	
	public T setData(T data) 
	
	{
		
		return data;
		
	}
	


	
	public void setRight (TreeNode<T> right) 
	{
		
		this.rightTranslation=right;
		
	}
	
	public void setLeft(TreeNode<T> left) 
	{
		
		this.leftTranslation = left;
		
		
	}
	
	public TreeNode<T> getLeft()
	
	{
		
		return leftTranslation;
		
	}
	
public T getData() 
	
	{
		
		return convert;
		
	}

	
	
	public TreeNode<T> getRight()
	
	{
		
		return rightTranslation ;
	}
	
	@SuppressWarnings("unchecked")
	public TreeNode(TreeNode<String> node) 
	
	{
		this.leftTranslation= new TreeNode<>(node.leftTranslation);
		
		this.rightTranslation= new TreeNode<>(node.rightTranslation);
		
		this.convert = (T) node.convert;
		
	}
	
}
