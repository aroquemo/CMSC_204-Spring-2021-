
public class ArraySum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}
		
		
		public int sumOfArray (Integer[] a,int index)
		
		
		{
			if (index <= 0)
			{
				
				return 0;
				
			}
			
			return (sumOfArray(a , index -1) + a [index - 1 ] );
			
	
		
		}	
		
		
		
		
		
		
		
		

}

