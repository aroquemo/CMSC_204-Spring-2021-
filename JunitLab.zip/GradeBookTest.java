import static org.junit.Assert.*;

	import org.junit.After;
	import org.junit.Before;
	import org.junit.Test;

	public class GradeBookTest

	{

		GradeBook g1, g2;
		
		
		@Before
		public void setUp() throws Exception {
			
			g1 = new GradeBook(2);
			
			g2 = new GradeBook(2);
			
			
			g1.addScore(60);
			
			g1.addScore(70);
			
			
			g2.addScore(80);
			
			g2.addScore(90);
			
			
		}

		@After
		public void tearDown() throws Exception {
			
			g1 = g2 = null;
			
		}

		@Test
		public void testAddScore() {
		
			g1 = g2 = null;
			
		}

		@Test
		public void testSum() {
			
			assertTrue(130 == g1.sum());
		
			assertTrue(170 == g2.sum());
			
			
			
		}

		@Test
		public void testMinimum() {
			
			assertTrue(60 == g1.minimum());
			
			assertTrue(80 == g2.minimum());
			
			
			
		}

		@Test
		public void testFinalScore() {
			assertTrue(130 == g1.sum());
			
			assertTrue(170 == g2.sum());
			
		}

		@Test
		public void testGetScoreSize() {
			
			
			assertTrue(2 == g1.sum());
			
			assertTrue(2 == g2.sum());
			
		}

		@Test
		public void testToString() {
			
	assertTrue("60, 70 ".equals(g1.toString()));
			
	assertTrue("80, 90 ".equals(g2.toString()));
			
		}

	}


