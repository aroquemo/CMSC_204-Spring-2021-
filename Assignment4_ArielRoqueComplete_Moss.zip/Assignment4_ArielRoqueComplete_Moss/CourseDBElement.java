//package application;

/**
 * CourseDBElement implements Comparable, and consists of five attributes: the Course ID (a String), 
 * the CRN (an int), the number of credits (an int), the room number (a String), and the instructor name (a String).   
 * Normally the CourseDBElement will be an object consisting of these five attributes, and is referred to as a CDE.
 * Programmer: Ariel Roque
 * CMSC 204, CRN 32191
 * Professor Monshi
 *
 */

public class CourseDBElement implements Comparable {

	private String ID;
	
	private int crn;
	
	private int credits;
	
	private String room;
	
	private String prof;
	
	
	public CourseDBElement()
	
	{
		// the set up in order to organize credits, and CRN number
		
		this(null , 00000, 0,null,null);
		
	}
	
	
	// Setter to set each private INT/String to user input

	public CourseDBElement(String id, int crn, int credits, String location, String professor) {
		
		ID = id;
		
		this.crn = crn;
		
		this.credits = credits;
		
		room = location;
		
		prof = professor;
		
	}
	
	// hash code retrieval
	
public int hashCode()
	
	{
		String crn1=Integer.toString(crn);
		
		return crn1.hashCode();
		
	}

//method to compare and retireve class crns

	@Override
	public int compareTo(CourseDBElement element) 
	
	{
		
		if(element.crn==crn) 
		
		{
			
			return 0;
			
		}
		
		
		else
		
		{
			
			return 1;
			
		}
	}
	

// Set & Retireve user input CRN
	
	public void setCRN(int crn)
	
	{
		
		this.crn = crn;
		
	}
	

	public int getCRN()
	
	{
		
		return crn;
		
	}
	

	
	

// Method to return user input course informtation 
	
	public String toString() 
	
	{
		
		String course =" Course:"+ ID + " CRN: " + crn + " Credits: " + credits + " Instructor: " + prof + " Room: " + room;
		
		
		return course;
	}


}
