

import static org.junit.Assert.*;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CourseDBManager_STUDENT_Test {
	
	private CourseDBManagerInterface dbm = new CourseDBManager();
	
	
	CourseDBElement one= new CourseDBElement("CMSC100", 21556, 2, "Distance-Learning", "Janet E. Joy");
	
	
	CourseDBElement two= new CourseDBElement("CMSC100", 22344, 2,"SW217","Gloria E. Barron");

	
	@Before
	public void setUp() throws Exception
	
	{
		
		dbm = new CourseDBManager();

	}

	
	@After
	public void tearDown() throws Exception
	
	{
		
		dbm = null;
		
	}


	@Test
	public void testAdd() 
	
	{
		
		try 
		{
			
			dbm.add("CMSC100", 21556, 2, "Distance-Learning", "Janet E. Joy");
			
			dbm.add("CMSC100", 22344, 2,"SW217","Gloria E. Barron");
			
		}
		
		catch(Exception e) 
		
		{
			
			fail("This should not have caused an Exception");
			
			
		}
	}

	@Test
	public void testGet() 
	
	{
		
		try
		
		{
			
			dbm.add("ENGL101",10050,4,"HM203","David Lastname");
			
			dbm.add("CMSC140",12345,3,"CS104","Not the same");
			
			assertEquals(dbm.get(10050).toString(), one.toString());
			
			assertFalse(dbm.get(12345).toString().equals(two.toString()));
			
		}
		catch(Exception e) 
		
		{
			
			fail("This should not have caused an Exception");
			
			
		}
		
	}
	
	

	@Test
	public void testReadFile() 
	
	{
		
		try 
		
		{
			File inputFile = new File("coures.txt");
			
			PrintWriter inFile = new PrintWriter(inputFile);
			
			inFile.println("CMSC100 21556 2 Distance-Learning Janet E. Joy");
			
			inFile.println("CMSC100 22344 2 SW217 Gloria E. Barron");
			
			inFile.println("CMSC100 22974 2 Distance-Learning Janet E. Joy");
			
			inFile.print("CMSC110 21561 3 SC451 Rabiha J. Kayed");
			
			inFile.close();
			
			dbm.readFile(inputFile);
			
			ArrayList<String> list = dbm.showAll();
			
			assertEquals(list.get(1),"\nCourse:CMSC100 CRN:21556 Credits:2 Instructor:Janet E. Joy Room:Distance-Leanring");
			
			
			assertEquals(list.get(0),"\nCourse:CMSC100 CRN:22344 Credits:2 Instructor:Gloria E. Barron Room:CSW217");
			
			
			assertEquals(list.get(2),"\nCourse:CMSC110 CRN:22974 Credits:2 Instructor:Janet E. Joy Room:Distance-Learning");
			
			
			assertEquals(list.get(3),"\nCourse:CMSC110 CRN:20484 Credits:3 Instructor:SRabiha J. Kayed Room:SC451");
		}
		
		catch (Exception e)
		
		{
			
			fail("Should not have thrown an exception");
			
			
		}
	}

	@Test
	public void testShowAll()
	
	{
		
		dbm.add("CMSC100" ,21556, 2, "Distance-Learning", "Janet E. Joy");
		
		dbm.add("CMSC100", 22344, 2 ,"SW217" ,"Gloria E. Barron");
		
		dbm.add("CMSC100" ,22974, 2, "Distance-Learning", "Janet E. Joy");
		
		dbm.add("CMSC110", 21561, 3, "SC451", "Rabiha J. Kayed");
		
		ArrayList<String> list = dbm.showAll();
		
		assertEquals(list.get(0),"\nCourse:CMSC100 CRN:21556 Credits:2 Instructor:Janet E. Joy Room:Distance-Leanring");
		
		assertEquals(list.get(1),"\nCourse:CMSC100 CRN:22344 Credits:2 Instructor:Gloria E. Barron Room:CSW217");
		
		assertEquals(list.get(2),"\nCourse:CMSC110 CRN:22974 Credits:2 Instructor:Janet E. Joy Room:Distance-Learning");
		
		assertEquals(list.get(3),"\nCourse:CMSC110 CRN:20484 Credits:3 Instructor:SRabiha J. Kayed Room:SC451");
		
		
		assertTrue(list.size()==dbm.showAll().size());
	}

}