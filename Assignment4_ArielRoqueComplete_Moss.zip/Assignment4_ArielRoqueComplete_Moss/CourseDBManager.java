

/**
 * Implements the CourseDBManagerInterface that is provided.
The data manager allows the user to read the courses from a file or to enter the data by hand, 
and uses an Alert to print out the database elements. The input is read from a file or read from the textfields and is added to the data structure through the add method.  
The add method uses the CDS add method. The CourseDBManager is also referred to as a CDM.
Programmer: Ariel Roque
 * CMSC 204, CRN 32191
 * Professor Monshi
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class CourseDBManager implements CourseDBManagerInterface {
	
	
	private ArrayList<Integer> crnArray;
	

	CourseDBStructure cds = new CourseDBStructure();
	
	@Override
	public void add(String id, int crn, int credits, String location, String instructor) 
	
	{
		
		CourseDBElement cde = new CourseDBElement(id,crn, credits, location, instructor);
		
		cds.add(cde);
		
	}


	@Override
	public CourseDBElement get(int crn) 
	
	{
		try 
		
		{
			
			return cds.get(crn);
			
		}
		
		catch(IOException e) 
		
		{
			
			return null;
			
		}
		
	
	}


	@Override
	public void readFile(File input) throws FileNotFoundException 
	
	{
		
		Scanner next = new Scanner(input);
		
		int credits, crn;
		
		CourseDBElement cde;
		
		String courses;
		
		String[] course;
		
		
		while (next.hasNextLine()) 
		
		{
			
			courses = next.nextLine();
			
			course = courses.split(" ",5);
			
			crn = Integer.parseInt(course[1]);
			
			credits = Integer.parseInt(course[2]);
			
			cde = new CourseDBElement(course[0], crn, credits, course[3], course[4]);
			
			
			cds.add(cde);
		}
		
	}
	
	/**
	 * showAll will sort the courses by crn and return all 
	 * elements in order
	 */
	@Override
	public ArrayList<String> showAll() {
		ArrayList<String> ordered = new ArrayList<>();
		Collections.sort(crnArray);
		for(int i=0; i<crnArray.size();i++) {
			ordered.add("\n"+get(crnArray.get(i)).toString());
		}
		return ordered;
	}	
//	@Override
//	public ArrayList<String> showAll()
//	{
//		return cds.showAll();
//		
//	}
	
}