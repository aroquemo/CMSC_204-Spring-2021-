import java.io.IOException;
import java.util.LinkedList;

/**
 * Implements the CourseDBStructureInterface that is provided.
*You will be implementing a hash table with buckets.  It will be an array of linked lists of CourseDBElements.  
*Each CDE will have a hash code that comes from the CRN, since the CRN is unique for courses.  Note that the CRN is an int, 
*and the tests require the hashcode of a string, so you will need to coerce it to a String, and take the hash code of the resulting string.  
*The add method will take a CourseDBElement and add it to the data structure. If a linked list at the relevant hash code doesn�t exist, 
*create a LinkedList with the first element being the CDE and add it to the HashTable. If the LinkedList already exists, add the CDE to the 
*existing list.
* Two constructors for the CDS will be required, one that takes in an integer that is the estimated number of courses, the other is used for
 * Programmer: Ariel Roque
 * CMSC 204, CRN 32191
 * Professor Monshi
 * */

public class CourseDBStructure implements CourseDBStructureInterface{

	private int size = 0;
	
	LinkedList<CourseDBElement>[] hashTable;
	
	private CourseDBElement object;
	
	
	@SuppressWarnings("unchecked")
	public CourseDBStructure(int size) 
	
	{
		
		hashTable = new LinkedList[size];
		
	}
	
	@Override
	public void add(CourseDBElement current) 
	
	{
		
		int c = current.hashCode()%getTableSize();
		
		if(hashTable[c] == null)
		
		{
			
			hashTable[c] = new LinkedList<CourseDBElement>();
			
			hashTable[c].add(current);
			
		}
		
		else hashTable[c].add(current);
		
		
		size++;
		
	}
	
	@SuppressWarnings("unchecked")
	public CourseDBStructure(String test, int sizeOfTable)
	
	{
		
		hashTable = new LinkedList[sizeOfTable];
		
	}
	
	public CourseDBStructure() 
	
	{
		
		hashTable = new LinkedList[100];
		
	}
	


	@Override
	public int getTableSize() {
		
		
		return hashTable.length;
	}
	
	@Override
	public CourseDBElement get(int crn) throws IOException {
		
		String currentCRN = Integer.toString(crn);
		
		int current = currentCRN.hashCode()%getTableSize();
		
		if(hashTable[current] != null) 
		
		{
			
			int newIndex = hashTable[current].size();
			
			newIndex--;
			
			while(hashTable[current].get(newIndex).getCRN()!=crn) 
			
			{
				
				newIndex--;
				
				
			}
			
			object = hashTable[current].get(newIndex);
			
			return object;
		}
		else throw new IOException();
	}
	
	
	

}

