//package application;

import java.io.*;
import java.util.*;


public interface Comparable {

	int compareTo(CourseDBElement element);

}