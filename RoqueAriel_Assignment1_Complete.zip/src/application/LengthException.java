package application;

public class LengthException extends Exception 

{
	
	public LengthException () 
	
	{
		
		super("The password must be atleast six characters");
		
	}
	
	public LengthException (String message) 
	
	{
		
		
		super (message);
		
		
	}

}
