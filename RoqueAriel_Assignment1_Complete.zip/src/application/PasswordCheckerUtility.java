package application;


/**
 * CMSC 204 Assignment 1: This assignment is a password checker. The user will be able to create a password and be told the password is valid if it meets all the requirments
 * Have at least one upper and lower case letter, one digit, longer than 6 characters, and 1 special character
 * Based off what the user inputs they will be told what they are missing or whether their password is weak or not.
 * 
 * Professor: Khandan Monshi
 * Class: CMSC 204 CRN: 32191
 * Assignment 1
 * Ariel Roque
 * Due date: 02/08/2021
 */

import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class PasswordCheckerUtility {
	
	
	public PasswordCheckerUtility()
	
	{}
	
	/**
	 * Method checks for validation of passwords
	 * Using all exceptions
	 
	 */
	
	
	public static boolean isValidPassword(String valid) throws LengthException, NoUpperAlphaException,
	NoLowerAlphaException, NoDigitException, NoSpecialCharacterException, InvalidSequenceException {
		
		// Boolean values in order to help validate passwords 
		
	boolean	invalidPassword = true;
		
	boolean	noUpperCaseUsed = false;
	
	boolean noLowerCaseUsed = false;
	
	boolean noDigitsUsed = false;
		
	
	boolean usedDigits = true;
	
	boolean usedUpper = true;
	
	boolean usedLower = true;
	
	
	// if statements to help check the validity of each password
	// If password does not meet the requirements, the code will call for the proper exception
	// as well as a display a message to help user figure out what the are missing for
	// a valid password
	
		if (valid.length() < 6 ) 
		{
			
			invalidPassword = false;
			
			throw new LengthException(valid + " Password must have atleast 6 characters.");
			
		}
		
	
		if (noUpperCaseUsed == false)
		{
			
			invalidPassword = false;
			
			throw new NoUpperAlphaException(valid + " Password must have an upper case letter." );
			
		}
		
		
		if (noLowerCaseUsed == false)
		{
			
			invalidPassword = false;
			
			throw new NoLowerAlphaException(valid+ " Password must have an lower case letter.");
			
		}
		
		if (noDigitsUsed == false) 
		
		{
			
			invalidPassword = false;
			
			throw new NoDigitException(valid+ " Password must have one digit letter.");
		}
		
	if (usedUpper == true)
	{
		
		invalidPassword = true;
		
		
	}
		if (usedLower = true) 
		{
			
			invalidPassword = true;
			
		}
		
		
	if (usedDigits == true)
	{
		
		invalidPassword = true;
		
	}
			
		
	
		return invalidPassword;
	
	}	
	

	
	/**
	 * Method checks for weakness of password
	 * will tell user if the password is valid 
	 * but also will tell the user that their password is weak
	
	 */
	public static boolean isWeakPassword(String password) throws WeakPasswordException
	
	{

		// password checks to see if password is at minimum 6 password and
		// will tell user if their password is weak based on length of their password
		
		return (password.length() >= 6);
		
	}
	
	/**
	 * 
	 * method to check if character is using lower cases
	 * i was having trouble with the code and identifying when the password is missing a lower case
	 */
	
	public static boolean hasLowerAlpha(String password) throws NoLowerAlphaException{
		
		
		// Using given hint from assignment one doc to identify pattern of lower case letters
		
		String pattern = "[a-z]*";
		
		Pattern invalid = Pattern.compile(pattern);
		
		Matcher matcher = invalid.matcher(password);
		
		return (!matcher.matches());
			
	}
	
	
	/**
	 * check for passwords and return an ArrayList with status of any valid passwords
	 */
	
	public static ArrayList <String> getInvalidPasswords (ArrayList <String> valid){
		
		ArrayList <String> invalid = new ArrayList<String>();
	
		
	// For loop in order to implement x into try and catch statements	
		for(int x = 0; x < valid.size(); x++)
		
		{
			
			//try statement to check for valid passwords of x from for loop
			
			try 
			
			{	
	
				PasswordCheckerUtility.isValidPassword(valid.get(x));
			
			} 
			
			// catch statement in order to retrieve a message and get the correct message

			catch (Exception e) 
			
			{

				invalid.add(valid.get(x) + e.getMessage());

			}

		}
		
		// return the valid passwords
		
		return invalid;
	
	}
	
}
