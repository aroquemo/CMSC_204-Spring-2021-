package application;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class PasswordCheckerTest {
	ArrayList<String> p;
	String t1 , d1;

	@Before
	
	public void setUp() throws Exception 
	
	{
		
		
		String[] txt = {"a1A#b1Bc1Cd1D", "334455BB#", "Im2cool4U#", "george2ZZZ#","4Sale#", "bertha22#", "4wardMarch#", 
				"august30", "a2cDe", "ApplesxxYYzz#", "aa11b", "pilotProject", "myPassword", 
				"myPassword2", "myPassword2#"};
	
		p = new ArrayList<String>();
		
		p.addAll(Arrays.asList(txt));
		
		
	
	}

	@After
	public void tearDown() throws Exception {
		p = null;
	}

	
	@Test
	public void testIsValidPasswordTooShort()
	
	{
		
		try
	
		{
			
			assertTrue(PasswordCheckerUtility.isValidPassword("a1A#b1Bc1Cd1D"));
			
			PasswordCheckerUtility.isValidPassword("ab12#");
			
			
		}
		
		catch(LengthException e)
		
		{
			
			assertTrue("Successfully threw a lengthExcepetion",true);
			
		}
	
		catch(Exception e)
		
		{
			
			assertTrue("Threw some other exception besides lengthException",false);
			
		}
		
	}
	
	
	@Test
	
	public void testIsValidPasswordNoUpperAlpha()
	{
		
		try
		
		{
			
			assertTrue(PasswordCheckerUtility.isValidPassword("334455BB#"));
			
			PasswordCheckerUtility.isValidPassword("33445");
			
		}
		
		catch(NoUpperAlphaException e)
		
		{
			
			assertTrue("Successfully threw a NoUpperAlphaExcepetion",true);
			
		}
		
		
		catch(Exception e)
		
		{
			
			assertTrue("Threw some other exception besides NoUpperAlphaException",false);
			
		}
	}
	
	
	@Test
	
	public void testIsValidPasswordNoLowerAlpha()
	{
		
		try
		
		{
			
			assertTrue(PasswordCheckerUtility.isValidPassword("1Im2cool4U#"));
			
			PasswordCheckerUtility.isValidPassword("Im2cool4U#");
			
		}
		
		
		catch(NoLowerAlphaException e)
		
		{
			
			assertTrue("Successfully threw a NoLowerAlphaExcepetion",true);
			
		}
	
		
		catch(Exception e)
		
		{
			
			assertTrue("Threw some other exception besides NoLowerAlphaException",false);
			
			
		}
	}
	

	@Test
	
	public void testIsWeakPassword()
	
	
	{
		
		try
		
		{
			
			assertEquals(true,PasswordCheckerUtility.isValidPassword("george2ZZZ#"));
			
			boolean weakPwd = PasswordCheckerUtility.isWeakPassword("george2ZZZ#");
			
			
		}
		
		
		catch(Exception e)
		
		{
			System.out.println(e.getMessage());
			
			assertTrue("Threw some incorrect exception",false);
			
		}
	}
	
	
	
	@Test
	public void testIsValidPasswordInvalidSequence()
	
	{
		try
		
		{
			
			assertEquals(true,PasswordCheckerUtility.isValidPassword("4Sale#"));
			
			PasswordCheckerUtility.isValidPassword("4Sale#");
			
			
		}
		
		
		catch(InvalidSequenceException e)
		
		{
			
			assertTrue("Successfully threw an InvalidSequenceExcepetion",true);
			
			
		}
	
		
		
		catch(Exception e)
		
		{
			
			System.out.println(e.getMessage());
			
			assertTrue("Threw some other exception besides an InvalidSequenceException",false);
			
		}
	}


	@Test
	public void testWeakPassword()
	
	{
		try
		
		{
			
			assertEquals(true,PasswordCheckerUtility.isValidPassword("bertha22#"));
			
			PasswordCheckerUtility.isValidPassword("bertha22#");
			
			
		}
		
		
		catch(InvalidSequenceException e)
		
		{
			
			assertTrue("Successfully threw an InvalidSequenceExcepetion",true);
			
			
		}
	
		
		
		catch(Exception e)
		
		{
			
			System.out.println(e.getMessage());
			
			assertTrue("Threw some other exception besides an InvalidSequenceException",false);
			
		}
	}
	
	
}
