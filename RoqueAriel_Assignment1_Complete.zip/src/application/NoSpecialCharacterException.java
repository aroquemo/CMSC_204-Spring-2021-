package application;

public class NoSpecialCharacterException extends Exception

{
	
	
	public NoSpecialCharacterException() 
	
	{
		
		super("Password must contain atleast one special character.");
		
	}
	
	public NoSpecialCharacterException(String message)
	
	{
		
		super(message);
		
	}
	
}
