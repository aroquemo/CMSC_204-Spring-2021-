package application;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;


/**
 * Within the Graph interface is a method shortestPath, which finds the shortest path from a given source Town to a destination Town. 
 * Since there is a unique shortest path from every vertex to the source, there is a back-pointer to the previous vertex.  
 * The method shortestPath calls dijkstraShortestPath which finds the shortest path from the source to every other vertex in the graph.  
 * You will be coding the Dijkstra�s Shortest Path algorithm.
 *   You will then be able to find the connections between two towns through the roads that connect them.
 * 
 * 
 * Programmer: Ariel Roque
 * CMSC 204, CRN: 32191
 *
 *
 */

public class Graph implements GraphInterface<Town, Road>{
	

	private Town prevTown;

	
	private Set<Town> towns = new HashSet<>();
	
	private Set<Road> roads = new HashSet<>();
	
	
	Road roadPath=null;
	
	private int adjacencyMatrix[][];
	
	 ArrayList<String> path = new ArrayList<>();
	 
	 private Set<Town> prevTowns = new HashSet<>();
	 
	 private Set<Town> desPrevTowns = new HashSet<>();
	 
	 Iterator<Town> checkT = prevTowns.iterator();
	 

	 public void setPath(Road min) {
			this.roadPath= min;
		}
		
		public Road getPath() {
			return roadPath;
		}
		
		public String getPathToString() {
		
			return getPath().getSource().toString()+ " via "+ getPath().toString()+
					" to "+getPath().getDestination()+ " " + getPath().getWeight()+" mi";
		}
		
		public int maxWeight() {
		
			int maxWeight=0;
	
			return maxWeight;
		}

	 
	@Override
	public Road getEdge(Town sourceVertex, Town destinationVertex) {		
		Iterator<Road> r = roads.iterator();
		
		Road currentRoad;
		
		while(r.hasNext()) {
			
			currentRoad=r.next();
			
			if(currentRoad.contains(sourceVertex)&&currentRoad.contains(destinationVertex))
				
				return currentRoad;
			
		}
		return null;
	}
	  
	@Override
	public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		Road edgeToAdd;
		
		edgeToAdd = new Road(sourceVertex, destinationVertex, weight,description);
		
		roads.add(edgeToAdd);
		
		return edgeToAdd;
		
	}
   
	@Override
	public boolean addVertex(Town v) {
		if(v==null)
			
			throw new NullPointerException();
		
		while(towns.contains(v))
			
			return false;
		
		towns.add(v);
		
		return true;
	}
	
    
	@Override
	public boolean containsEdge(Town sourceVertex, Town destinationVertex) {
		Iterator<Road> r = roads.iterator();
		Road currentRoad;
		while(r.hasNext()) {
			
			currentRoad=r.next();
			
			if(currentRoad.contains(sourceVertex)&&currentRoad.contains(destinationVertex))
				
				return true;
		}
		return false;
	}
	
	@Override
	public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		if(towns.contains(sourceVertex)==false || towns.contains(destinationVertex)==false)
			throw new IllegalArgumentException();
		
		Iterator<Road> r = roads.iterator();
		
		Road currentRoad;
		
		while(r.hasNext()) {
			
			currentRoad=r.next();
			
			if(currentRoad.contains(sourceVertex)&&currentRoad.contains(destinationVertex)) {
				
				roads.remove(currentRoad);
				
				return currentRoad;
				
			}
			
		}
		return null;
		
	}
    
	@Override
	public boolean removeVertex(Town v) {
		if(v==null)
			return false;
		
		if(towns.contains(v)) {
			
			towns.remove(v);
			
		return true;
		
		}
		
		return false;
		
	}
	
	@Override
	public boolean containsVertex(Town v) {
		if(towns.contains(v)) {
			
			return true;
		}
		if(v==null)
			
			return false;
		
		return false;
	}
  
	@Override
	public Set<Road> edgeSet() {
		// TODO Auto-generated method stub
		return roads;
	}
    
	public Set<Road> edgesOf(Town vertex) {
		
		Iterator<Town> t = towns.iterator();
		
		boolean status=false;
		
		while(t.hasNext()){
			
			if(t.next()!=vertex) {
				
				status=true;
				
				}
		}
		
		if(status == false) {
			
			throw new IllegalArgumentException();
			
		}
		
		if(vertex==null) {
			
			throw new NullPointerException();
		}
		
		Set<Road> roadsAtVertex= new HashSet<>();
		

		
	
		
		return roadsAtVertex;
	}
	
   
	
   
	@Override
	public Set<Town> vertexSet() {
		return towns;
	}
   
	@Override
	public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {
		
		
		dijkstraShortestPath(sourceVertex);

		
		return path;
	
	}
   
	@Override
	public void dijkstraShortestPath(Town sourceVertex) {
		
		ArrayList<Town> visitedV = new ArrayList<>();
		
		ArrayList<Town> notVistedV = new ArrayList<>();
		
		notVistedV.addAll(towns);
		
		notVistedV.remove(sourceVertex);
		
	
		if(edgesOf(sourceVertex).size()==0) {
			return;
		}
		
		
		Road currE;
		
		Town currEV;
		
		if(edgesOf(sourceVertex).size()==1) {
			
			Set<Road> currVE=edgesOf(sourceVertex);
			
			Iterator<Road> e = currVE.iterator();
			
			currE=e.next();
			
			currEV=currE.getDestination();
			
			visitedV.add(currEV);
			
			notVistedV.remove(currEV);
			
			roadPath=currE;
			
			path.add(getPathToString());
			
		
			sourceVertex=currEV;
			}
		
		
		if(edgesOf(sourceVertex).size()>1) {
				whileLoop(sourceVertex, visitedV,notVistedV);
			}
			return;
			
		}
		

	
	
	
	public void checkRowSum() {
		
		int checkRow=0;
		
		for(int x =0; x<towns.size(); x++) {
			
			
			
			 checkRow=0;
			 
			for(int i = 0; i < towns.size(); i++) {
				
		
				checkRow+=adjacencyMatrix[x][i];
			}
		
			}
	}
	
	public Set<Town> checkVE(Town source) {
		Set<Road> checkTowns=edgesOf(source);
		
		
		Iterator<Road> sourceRoads = checkTowns.iterator();
		
		Set<Town> townOfSouce= new HashSet<>();
		
		
		while(sourceRoads.hasNext()) {
			
			Road curr=sourceRoads.next();
			
			if(source == curr.getDestination() && !(prevTowns.contains(source)))
				
				townOfSouce.add(curr.getSource());
			
			if(source == curr.getSource() && !(prevTowns.contains(source)))
				
				townOfSouce.add(curr.getDestination());
		
		}
		
	
		prevTown=source;
		prevTowns.add(prevTown);
		
		return townOfSouce;
	}
	
	public Set<Town> backCheckVE(Town source) {
		Set<Road> checkTowns=edgesOf(source);
	
		
		Iterator<Road> sourceRoads = checkTowns.iterator();
		
		Set<Town> townOfSouce= new HashSet<>();
		
		while(sourceRoads.hasNext()) {
			
			Road curr=sourceRoads.next();
			
			if(source == curr.getDestination() && !(desPrevTowns.contains(source)))
				
				townOfSouce.add(curr.getSource());
			
		}
		
		
		
		
		prevTown=source;
		desPrevTowns.add(prevTown);
	
		return townOfSouce;
	}
	
	public void whileLoop(Town sourceVertex, ArrayList<Town> visitedV, ArrayList<Town> notVistedV ){
		if(edgesOf(sourceVertex).size()>1) {
			
			Set<Road> edge=edgesOf(sourceVertex);
			
			Iterator<Road> e = edge.iterator();
			
			while(e.hasNext()) {
				Road currentEdge;
			
				currentEdge=e.next();
				
				
				
				
				if(visitedV.contains(currentEdge.getDestination())) {
					if(e.hasNext()) {
						currentEdge=e.next();
					}
					
				}
			}
	
	}

	
	}
    /** 
     * Builds the adjacency matrix 
     */
	public void buildMatrix() {
		Iterator<Town> row = towns.iterator();
		
		Iterator<Town> col = towns.iterator();
		
		Town currTownRow=null;
		
		Town currTownCol=null;
		
		adjacencyMatrix= new int[towns.size()][towns.size()];
		while(row.hasNext()) {
			
			for(int x =0; x< towns.size() ; x++) {
				
				currTownRow=row.next();
				
				col = towns.iterator();
				
				while(col.hasNext()) {
					
					for(int i=0; i<towns.size(); i++) {
						
						currTownCol=col.next();
						
						if(currTownRow==currTownCol)
							
							adjacencyMatrix[x][i]= 0;
						
						
						
						else adjacencyMatrix[x][i]= 0;
						
						}
					}
				}
			}
		checkRowSum();
	}
	
	
	
	
}