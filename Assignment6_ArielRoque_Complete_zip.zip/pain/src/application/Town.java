package application;

import java.util.ArrayList;


import java.util.LinkedHashSet;

/**
 *Create a Town class that holds the name of the town and a list of adjacent towns, and other fields as desired, and the traditional methods (constructors, getters/setters, toString, etc.).  It will implement the Comparable interface.  This is the class header:
	public class Town implements Comparable<Town>
	Two towns will be considered the same if their name is the same.
 * 
 * * Programmer: Ariel Roque
 * CMSC 204, CRN: 32191
 *
 */

public class Town implements Comparable<Town>{
	
	
	
	String name;
	LinkedHashSet<Town> adjacentTowns;
	
	Town(Town template){
		
		name = template.getName();
		
		adjacentTowns = template.adjacentTowns;
	}

	Town(String name){
		
		this.name = name;
		
		adjacentTowns = new LinkedHashSet<Town>();
		
	}
	
	
	
	
	public String getName() { 
		
		return name; 
		
	}

	


	public LinkedHashSet getAdjacentSet() 
	
	{
		return adjacentTowns; 
		
	}
	
	

	
	@Override
	public int compareTo(Town o) 
	
	{
		return name.compareTo(o.getName()); 
		
	}
	
	

	
	

	
	public int hashCode() 
	{ 
		
		return name.hashCode(); 
		
	}
	
	

	public String toString() 
	{ 
		return name;
		
	}
	
	
public boolean equals(Object o) { 
		
		if (!(o instanceof Town)) 
		
		{
			return false;
		}
		
		return (this.compareTo((Town) o) == 0) ? true : false; 
	
	}
	

	
	
}
