package application;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;



public class TownGraph implements GraphInterface<Town, Road> {

	
	
	HashMap<Town, LinkedHashSet<Town>> closeMap;
	
	HashMap<Town, LinkedHashSet<Road>> next;
	
	HashSet<Road> mapSet;
	
	ArrayList<Town> vertexList;
	
	int[] distanceArray;
	
	Town[] previousVertexArray;
	
	
	TownGraph()
	
	{
		closeMap = new HashMap<Town, LinkedHashSet<Town>>();
		
		next = new HashMap<Town, LinkedHashSet<Road>>();
		
		mapSet = new HashSet<Road>();
	}
	
	
	
	

	
	@Override
	public Road getEdge(Town sourceVertex, Town destinationVertex)
	
	{
		
		if(closeMap.get(sourceVertex).contains(destinationVertex))
		
		{
			
			for(Road road : mapSet) 
			
			{
				if(road.connects(sourceVertex, destinationVertex))

				{
					
					return road;
					
				}
			}
			
		}
		
		return null;
		
	}

	
	 
	@Override
	public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description) throws IllegalArgumentException {
		
		Road road = new Road(sourceVertex, destinationVertex, weight, description);
		
		if(!containsVertex(sourceVertex) || !containsVertex(sourceVertex))
		
		{
			
			throw new IllegalArgumentException();
			
		}
		
		if(!next.keySet().contains(sourceVertex) || !next.keySet().contains(destinationVertex)) 
		
		{
			
			throw new IllegalArgumentException();
			
		}
		
		
		next.get(sourceVertex).add(road);
		
		next.get(destinationVertex).add(road);
		
		closeMap.get(sourceVertex).add(destinationVertex);
		
		
		closeMap.get(destinationVertex).add(sourceVertex);
		
		
		mapSet.add(road);
		
		return road;
		
	}

	
	
	
	@Override
	public boolean addVertex(Town town)
	
	{
		
		if(!closeMap.keySet().contains(town)) 
		
		{
			
			next.put(town, new LinkedHashSet<Road>());
			
			return true;
			
			
		}
		
		return false;
		
	}


	
	@Override
	public boolean containsEdge(Town sourceVertex, Town destinationVertex) 
	
	{
		
		for(Road road : mapSet) 
		
		{	
			
			 if (road.connects(sourceVertex, destinationVertex)) return true;
			 
		}
		
		return false;
	
	}

	
	
	
	@Override
	public boolean containsVertex(Town town) 
	
	{
		return closeMap.keySet().contains(town);
	}

	
	

	
	@Override
	public Set<Road> edgeSet() 
	
	{
		return mapSet;
	}

	
	
	
	public ArrayList<Town> getTowns() 
	{
		
		return vertexList;
		
	}
	
	

	
	public ArrayList<String> getTownNames() {
		
		ArrayList<String> names = new ArrayList<String>();
		
		for(Town t : closeMap.keySet()) 
		
		{
			
			names.add(t.toString());
			
		}
		
		return names;
		
	}
	
	@Override
	public String toString() {
		
		String s = "TOWNS\n";
		
		if(closeMap != null) {
			
			for(Town t : closeMap.keySet()) {
				
				s += t + "closeMap.get(t)";
				
			}
			
		}
		
		if(next != null) {
			
			for(Town t : next.keySet()) {
				
				s += t + " next.get(t)";
				
			}
			
		}
		return s;
	
	}
	

	
	@Override
	public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {
		
		dijkstraShortestPath(sourceVertex);
		
		System.out.println();
		
		Town temp = destinationVertex;
		
		ArrayList<String> history = new ArrayList<String>();
		
		if(previousVertexArray[vertexList.indexOf(temp)] != null) 
		
		{
			while(!temp.equals(sourceVertex)) {
				
				history.add(temp.toString());
				
				temp = previousVertexArray[vertexList.indexOf(temp)];
				
			}
		} else if (!sourceVertex.equals(destinationVertex)) {
			
			throw new UnsupportedOperationException();
			
		}
		

		
		return history;
	}
	
	
	
	@Override
	public Set<Road> edgesOf(Town vertex) throws NullPointerException 
	
	{

		if(next.keySet().contains(vertex))
		{
			return next.get(vertex);
		}
		
		throw new NullPointerException();
	
	}


	
	@Override
	public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		
		Road road = new Road(sourceVertex, destinationVertex, weight, description);
		
		if(mapSet.contains(road)) 
		
		{
			mapSet.remove(road);
			
			next.remove(sourceVertex);
			
			next.remove(destinationVertex);
			
			return road;
			
		}
		
		return null;
		
	}

	

	
	

	
	@Override
	
	public Set<Town> vertexSet() 
	
	{
		
		return closeMap.keySet();
		
	}


	
	
	
	@Override
	public void dijkstraShortestPath(Town startVertex) {
		
		int i = vertexSet().size();
		
		vertexList = new ArrayList<Town>();
		
		distanceArray = new int[i];
		
		previousVertexArray = new Town[i];
		
		Arrays.fill(distanceArray, Integer.MAX_VALUE);
		
		ArrayList<Town> unvisited = new ArrayList<Town>();
		
		ArrayList<Town> visited = new ArrayList<Town>();
		
		for (Town t : vertexSet()){
			
			vertexList.add(t);
			
			unvisited.add(t);
			
		}
		
		
		distanceArray[vertexList.indexOf(startVertex)] = 0;
		
		

		Town source;
		
		while(!unvisited.isEmpty()) {
			
			int smallestDistIndex = vertexList.indexOf(unvisited.get(0));
			
			for(int x = 0; x < i; x++) {
				if(!visited.contains(vertexList.get(x)) && (distanceArray[x] < distanceArray[smallestDistIndex])) {
					
					smallestDistIndex = x;
					
				}
			}
			
			source = vertexList.get(smallestDistIndex);
			Town temp;
			
			for(Town t : closeMap.get(source)) {
				
				if(unvisited.contains(t)) {
					
					int indexOfCurrent = vertexList.indexOf(t);
					
					Town holdingOld = previousVertexArray[indexOfCurrent];
					
					
					if(vertexList.get(indexOfCurrent) != startVertex) {
						
						previousVertexArray[indexOfCurrent] = source;
						
					}
					
			
				}
				
			}
			
			visited.add(source);
			unvisited.remove(source);
			
			
			
		}		
		
		
	}
	
	@Override
	public boolean removeVertex(Town town) {
		
		
		if(closeMap.keySet().contains(town)) {
			
			
			for(Town key : closeMap.keySet()) 
			
			{
				closeMap.get(key).removeAll(Collections.singleton(town));
			
				
			}
			
			
			closeMap.remove(town);
			
			next.remove(town);
			
			return true;
			
			
		}

		return false;
		
	}

	
	
	
	
	
	
	
}
