package application;

/**
 *Create a class Road that can represent the edges of a Graph of Towns.  The class must implement Comparable.  
 *The class stores references to the two vertices(Town endpoints), 
 *the distance between vertices, and a name, and the traditional methods (constructors, getters/setters, toString, etc.),
 * and a compareTo, which compares two Road objects. \
 *Since this is a undirected graph, an edge from A to B is equal to an edge from B to A. This is the class header:
 * 
 * 
 * Programmer: Ariel Roque
 * CMSC 204, CRN: 32191
 * 
 *
 *
 */

public class Road implements Comparable<Road>{

	
	
	String name;
	
	Town one, two;
	
	int distance;
	
	public Road(Town source, Town destination, int weight, String name) {
		distance = weight;
		
		one = source;
		
		two = destination;
		
		this.name = name;
		
	}

	public Road(Town source, Town destination, String name) 
	
	{
		distance = 1;
		
		
		one = source;
		
		two = destination;
		
		this.name = name;
		
		
	}
	
	

	
	public boolean contains(Town town) {
		return (town.equals(one) || town.equals(two));
	}
	
	
	
	public boolean connects(Town town1, Town town2) {
		return (town1.equals(one) || town1.equals(two)) && (town2.equals(one) || town2.equals(two));
	}
	
	@Override
	public int compareTo(Road o) {
		
		return name.compareTo(o.getName());
	}

	
	
	public boolean equals(Road o) {
		
		
		return name.equals(o.getName());
		
	}
	
	public String getName() {
		return name;
	}
	
	

	
	public Town getSource() {
		return one;
	}
	
	
	
	
	public Town getDestination() {
		return two;
	}
	

	
	public int getWeight() {
		return distance;
	}
	

	@Override
	public boolean equals(Object r) {
		
		if (!(r instanceof Road)) {
			return false;
		}
	
		return false;
		
	}
	
	

	
	@Override
	public String toString() 
	
	{
		
		return name;
		
	}
	
	
	
}

