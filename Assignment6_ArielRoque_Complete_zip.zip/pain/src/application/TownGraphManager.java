package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;


/**
 * 
 * 
 * Programmer: Ariel Roque
 * CMSC 204, CRN: 32191
 *
 */

public class TownGraphManager<E> implements TownGraphManagerInterface {
	
	
	
	TownGraph graph;
	
	TownGraphManager(){
		graph = new TownGraph();
	}
	
	
	

	
	@Override
	public boolean addRoad(String town1, String town2, int weight, String roadName) {
		
		graph.addEdge(new Town (town1), new Town (town2), weight, roadName);
		 
		graph.edgeSet();
		
		return containsRoadConnection( town1,  town2);
		
	}

	

	
	@Override
	public String getRoad(String town1, String town2) {
		
		Town townA = new Town(town1);
		
		Town townB = new Town(town2);
		
		for(Road r : graph.next.get(townA))
		
		{
			if(r.connects(townA, townB))
			{
				
				return r.toString();
				
			}
			
		}
		
		return null;
		
	}

	
	
	
	@Override
	public boolean addTown(String v) {
		
		return graph.addVertex(new Town(v));
		
	}

	
	
	@Override
	public Town getTown(String name) {
		
		for(Town t : graph.vertexSet())
		
		{
			if(t.getName().equals(name))
			{
				
				return t;
				
			}
		}
		
		return null;
		
	}


	@Override
	public boolean containsTown(String v) {
		return graph.containsVertex(new Town(v));
	}
	
	

	@Override
	public boolean containsRoadConnection(String town1, String town2) {
		
		Town townA = new Town(town1);
		
		Town townB = new Town(town2);
		
		HashSet<Road> smallestSet = (graph.next.get(townA).size() < graph.next.get(townA).size()) ? graph.next.get(townA) : graph.next.get(townB);
		
		for(Road r : smallestSet) 
		{
			if(r.connects(townA, townB)) 
			{
				
				return true;
				
			}
		}
		
		return false;
		
	}


	
	@Override
	public ArrayList<String> allRoads() {
		
		ArrayList<String> list = new ArrayList<String>();
		
		for(Road r : graph.edgeSet()) {
			
			list.add(r.toString());
			
		}
		
		Collections.sort(list);
		
		return list;
		
		
	}

	
	
	
	
	@Override
	public boolean deleteRoadConnection(String town1, String town2, String road) {
		
		
		return false;
		
	}

	
	
	

	@Override
	public boolean deleteTown(String v) {
		
		return graph.removeVertex(new Town(v));
	}


	@Override
	public ArrayList<String> allTowns() {
		
		ArrayList<String> list = graph.getTownNames();
		
		Collections.sort(list);
		
		return list;
	}
	
	
	
	

	
	@Override
	public ArrayList<String> getPath(String town1, String town2) {
	
		Town townA = new Town(town1);
		
		
		Town townB = new Town(town2);
		
		return graph.shortestPath(townA, townB);
		
	}

	
	
	

	public void clearTownFields() {
		graph.vertexList = null;
		
		graph.distanceArray = null;
		
		graph.previousVertexArray = null;
		
	}

	



	public void populateTownGraph(File selectedFile) throws FileNotFoundException {
		// TODO Auto-generated method stub
		
	}
	
	

}
